# @author Siam Thanat Hack Co., Ltd. (STH)
# Contact for internship program:
#   - Website: https://sth.sh
#   - LINE: @siamthanathack
#   - Email: intern@sth.sh
from django.shortcuts import render, redirect
from .models import VanillaProduct
from django.db import connection, IntegrityError
from django.urls import reverse
from django.contrib import messages

# Create your views here.
def homepage(request):
    return render(request, 'home.html')

def search(request):
    search_query = request.GET.get('search_query', '')  
    products = []

    if search_query:
        try:
            # คำใบ้:
            # - มีช่องโหว่ UNION-based SQL Injection 
            # - Flag อยู่ในตารางข้อมูล ชื่อ webapp_vanillaproduct ใน Column ชื่อ ctf_flag
            # - https://portswigger.net/web-security/sql-injection/union-attacks
            # - https://github.com/swisskyrepo/PayloadsAllTheThings/blob/master/SQL%20Injection/SQLite%20Injection.md
            query = f"""
                SELECT * FROM webapp_vanillaproduct
                WHERE name LIKE '%{search_query}%'
            """
            cursor = connection.cursor()
            cursor.execute(query)  # Direct execution of raw SQL query
            results = cursor.fetchall()

            # Prepare products from the raw query result
            for result in results:
                product = VanillaProduct(id=result[0], name=result[1], description=result[2], image=result[3])
                products.append(product)

            # Redirect to the results page
            return render(request, 'search_results.html', {'products': products, 'search_query': search_query})

        except Exception as e:
            # Handle the SQL exception and show an alert message
            messages.error(request, f"An error occurred while processing your request: {str(e)}")
            return redirect('home')  # Redirect to home or another safe page
    else:
        # If no search term, show all products
        products = VanillaProduct.objects.all()

    return render(request, 'home.html', {'products': products})


def product_list(request):
    products = VanillaProduct.objects.all()  # Fetch all products from the database
    return render(request, 'product_list.html', {'products': products})