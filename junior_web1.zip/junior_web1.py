# @author Siam Thanat Hack Co., Ltd. (STH)
# Contact for internship program:
#   - Website: https://sth.sh
#   - LINE: @siamthanathack
#   - Email: intern@sth.sh
from django.shortcuts import render, redirect
from django.http import HttpResponse
from django.db import connection 
from django.contrib.auth.decorators import login_required


# Homepage Render
def home(request):
    return render(request, 'home.html')

# Login Function
def login(request):
    context = {}
    if request.method == "POST":
        username = request.POST.get('username', '')
        password = request.POST.get('password', '')

        # SQL Injection Vulnerability
        query = f"SELECT * FROM junior_web_1_users WHERE username = '{username}' AND password = '{password}'"
        
        with connection.cursor() as cursor:
            try:
                cursor.execute(query)  
                result = cursor.fetchone()  
                
                if result:
                    username = result[1]
                    request.session['logged_in'] = True
                    # Real Flag will be on the challenge server at:
                    # https://wtctt24.junior.web1.p7z.pw
                    context['message'] = f"Nice work, here is your flag: <_FLAG_WAS_REMOVED_>"
                else:
                    context['error'] = f"Invalid username or password."
            except Exception as e:
                context['error'] = f"An error occurred: {e}"

    return render(request, 'home.html', context)
