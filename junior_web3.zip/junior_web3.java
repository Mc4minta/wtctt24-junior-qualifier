// @author Siam Thanat Hack Co., Ltd. (STH)
// Contact for internship program:
//   - Website: https://sth.sh
//   - LINE: @siamthanathack
//   - Email: intern@sth.sh
package com.juniorwebapp3.demo.controller;

import com.juniorwebapp3.demo.model.User;
import com.juniorwebapp3.demo.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.ui.Model;
import jakarta.servlet.http.HttpSession;
import org.springframework.jdbc.core.JdbcTemplate;


@Controller
public class UserController {
    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    private UserService userService;

    @PostMapping("/login")
    public String login(@RequestParam String username, @RequestParam String password, Model model, HttpSession session) {
        User user = userService.findUserByUsername(username);

        // Check if user exists and password matches
        if (user != null && user.getPassword().equals(password)) {
            // Successful login, store user in session
            session.setAttribute("user", user);
            if ("admin".equals(username)) {
                return "redirect:/admin-dashboard";  // Redirect to admin dashboard if user is admin
            }
            return "redirect:/dashboard";  // Redirect to regular dashboard for other users
        } else {
            // If login fails, send an error message to the login page
            model.addAttribute("error", "Invalid username or password");
            return "redirect:/";  // Return to the login page with the error message
        }
    }

    @GetMapping("/dashboard")
    public String dashboard(HttpSession session, Model model) {
        // Check if the user is authenticated (exists in session)
        User loggedInUser = (User) session.getAttribute("user");
        if (loggedInUser != null) {
            // Add the logged-in user's username to the model to display in the view
            model.addAttribute("username", loggedInUser.getUsername());
            return "dashboard";  // Return the dashboard page if authenticated
        } else {
            // If the user is not authenticated, redirect to login
            model.addAttribute("error", "You must be logged in to view the dashboard.");
            return "login";  // Return to the login page
        }
    }

    @GetMapping("/admin-dashboard")
    public String adminDashboard(HttpSession session, Model model) {
        User loggedInUser = (User) session.getAttribute("user");
        if (loggedInUser != null && "admin".equals(loggedInUser.getUsername())) {
            // If user is admin, show admin dashboard
            model.addAttribute("username", loggedInUser.getUsername());
            return "admin";  // Admin can view the admin dashboard
        } else {
            // If not admin, redirect to the regular dashboard
            return "redirect:/dashboard";
        }
    }

    @PostMapping("/change-password")
public String changePassword(@RequestParam("password") String password,
                             @RequestParam("confirmPassword") String confirmPassword,
                             HttpSession session, Model model) {
    // Ensure passwords match
    if (!password.equals(confirmPassword)) {
        model.addAttribute("error", "Passwords do not match.");
        return "dashboard"; // Return to dashboard if validation fails
    }

    // Get the logged-in user from the session
    User user = (User) session.getAttribute("user");
    if (user != null) {
        // This part creates the second-order SQL injection
        String sql = "UPDATE `user` SET password = ? WHERE username = '" + user.getUsername() + "'";
        jdbcTemplate.update(sql, password);
        
        // Add the username to the model so it can be displayed in the view
        model.addAttribute("username", user.getUsername());
        model.addAttribute("success", "Password changed successfully.");
    } else {
        model.addAttribute("error", "User not authenticated.");
    }

    return "dashboard";  // Return to dashboard after updating the password
}

    @GetMapping("/logout")
    public String logout(HttpSession session, Model model) {
        // Invalidate the session to log out the user
        session.invalidate();

        // Optionally, add a success message or redirect to the login page
        model.addAttribute("success", "You have been logged out successfully.");

        // Redirect to the login page or home page
        return "redirect:/"; // Make sure you have a login page or home page
    }

    @GetMapping("/register")
    public String register() {
        return "register";
    }
    
    @PostMapping("/register")
    public String registerUser(
            @RequestParam("username") String username,
            @RequestParam("password") String password,
            Model model) {
        
        // Call service to register user
        User user = userService.registerUser(username, password);
        
        if (user == null) {
            model.addAttribute("error", "Username 'admin' is not allowed.");
            return "register";  // Return to registration page if username 'admin' is used
        }

        // Add success message
        model.addAttribute("message", "Registration successful!");
        return "index"; // Redirect to login page after successful registration
    }
}
